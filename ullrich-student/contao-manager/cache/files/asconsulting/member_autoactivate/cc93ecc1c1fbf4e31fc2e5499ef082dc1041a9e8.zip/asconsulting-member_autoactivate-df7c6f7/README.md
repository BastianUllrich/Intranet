# Member Auto-Activate
Auto activate member plugin for Contao 4+

## Usage
Configure in Contao registration module configuration. A checkbox enables auto-activation. Auto-activation can be restricted to certain domains. 

## Warning
Auto-activation of members allows for users to create accounts without verifing their email address. 