<?php

use Twig\Node\DoNode;

class_exists('Twig\Node\DoNode');

if (\false) {
    class Twig_Node_Do extends DoNode
    {
    }
}
