<?php

use Twig\TokenParser\DeprecatedTokenParser;

class_exists('Twig\TokenParser\DeprecatedTokenParser');

if (\false) {
    class Twig_TokenParser_Deprecated extends DeprecatedTokenParser
    {
    }
}
