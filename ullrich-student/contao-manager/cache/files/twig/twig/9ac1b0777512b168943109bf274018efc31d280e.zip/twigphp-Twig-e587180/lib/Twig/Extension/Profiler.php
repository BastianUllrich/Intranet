<?php

use Twig\Extension\ProfilerExtension;

class_exists('Twig\Extension\ProfilerExtension');

if (\false) {
    class Twig_Extension_Profiler extends ProfilerExtension
    {
    }
}
