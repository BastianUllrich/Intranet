<?php

use Twig\TokenParser\IfTokenParser;

class_exists('Twig\TokenParser\IfTokenParser');

if (\false) {
    class Twig_TokenParser_If extends IfTokenParser
    {
    }
}
