<?php

use Twig\TokenParser\ImportTokenParser;

class_exists('Twig\TokenParser\ImportTokenParser');

if (\false) {
    class Twig_TokenParser_Import extends ImportTokenParser
    {
    }
}
