<?php

use Twig\RuntimeLoader\RuntimeLoaderInterface;

class_exists('Twig\RuntimeLoader\RuntimeLoaderInterface');

if (\false) {
    class Twig_RuntimeLoaderInterface extends RuntimeLoaderInterface
    {
    }
}
