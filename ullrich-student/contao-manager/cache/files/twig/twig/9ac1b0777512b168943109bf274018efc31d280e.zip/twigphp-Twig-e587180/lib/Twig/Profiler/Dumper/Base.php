<?php

use Twig\Profiler\Dumper\BaseDumper;

class_exists('Twig\Profiler\Dumper\BaseDumper');

if (\false) {
    class Twig_Profiler_Dumper_Base extends BaseDumper
    {
    }
}
