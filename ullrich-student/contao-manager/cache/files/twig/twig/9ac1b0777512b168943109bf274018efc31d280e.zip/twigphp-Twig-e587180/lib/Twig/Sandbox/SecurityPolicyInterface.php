<?php

use Twig\Sandbox\SecurityPolicyInterface;

class_exists('Twig\Sandbox\SecurityPolicyInterface');

if (\false) {
    class Twig_Sandbox_SecurityPolicyInterface extends SecurityPolicyInterface
    {
    }
}
