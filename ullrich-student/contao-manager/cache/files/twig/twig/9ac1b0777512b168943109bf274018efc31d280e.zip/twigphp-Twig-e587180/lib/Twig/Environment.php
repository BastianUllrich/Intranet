<?php

use Twig\Environment;

class_exists('Twig\Environment');

if (\false) {
    class Twig_Environment extends Environment
    {
    }
}
