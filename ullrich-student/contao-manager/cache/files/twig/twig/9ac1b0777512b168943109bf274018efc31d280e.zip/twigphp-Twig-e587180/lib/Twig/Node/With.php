<?php

use Twig\Node\WithNode;

class_exists('Twig\Node\WithNode');

if (\false) {
    class Twig_Node_With extends WithNode
    {
    }
}
