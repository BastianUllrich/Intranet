<?php

use Twig\Profiler\Node\LeaveProfileNode;

class_exists('Twig\Profiler\Node\LeaveProfileNode');

if (\false) {
    class Twig_Profiler_Node_LeaveProfile extends LeaveProfileNode
    {
    }
}
