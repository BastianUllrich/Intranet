<?php

use Twig\TokenParser\ForTokenParser;

class_exists('Twig\TokenParser\ForTokenParser');

if (\false) {
    class Twig_TokenParser_For extends ForTokenParser
    {
    }
}
