<?php
$GLOBALS['TL_LANG']['tl_content']['mateTeaserBox_page'] = ['zu verlinkende Seite','Wählen Sie hier die zu verlinkende Seite aus.'];
$GLOBALS['TL_LANG']['tl_content']['mateTeaserBox_pageText'] = ['Link-Text','Geben Sie hier einen Link-Text ein.'];
$GLOBALS['TL_LANG']['tl_content']['mateContentBox_page'] = ['zu verlinkende Seite','Wählen Sie hier die zu verlinkende Seite aus.'];
$GLOBALS['TL_LANG']['tl_content']['mateContentBox_pageText'] = ['Link-Text','Geben Sie hier einen Link-Text ein.'];
$GLOBALS['TL_LANG']['tl_content']['mateTeaserBoxSettings'] = 'Teaserbox-Einstellungen';
$GLOBALS['TL_LANG']['tl_content']['mateContentBoxSettings'] = 'Contentbox-Einstellungen';
$GLOBALS['TL_LANG']['tl_content']['mateParallaxElementSettings'] = 'Parallax Einstellungen';
$GLOBALS['TL_LANG']['tl_content']['mateTextBackground_settings'] = 'Hintergrundbild Einstellungen';
$GLOBALS['TL_LANG']['tl_content']['mateContentBox_customTpl'] = ['Individuelles Template','Hier können Sie ein individuelles Template auswählen.'];
$GLOBALS['TL_LANG']['tl_content']['mateTeaserBox_customTpl'] = ['Individuelles Template','Hier können Sie ein individuelles Template auswählen.'];
$GLOBALS['TL_LANG']['tl_content']['mateParallaxElement_customTpl'] = ['Individuelles Template','Hier können Sie ein individuelles Template auswählen.'];
$GLOBALS['TL_LANG']['tl_content']['mateTeaserbox_subHeadline'] = ['Unterüberschrift','Hier können Sie eine Unterüberschrift eingeben.'];
$GLOBALS['TL_LANG']['tl_content']['mateParallaxElement_text'] = ['Text','Hier können Sie einen Text eingeben, der im Parallax Element angezeigt wird.'];
$GLOBALS['TL_LANG']['tl_content']['mateParallaxElement_height'] = ['Höhe in px','Geben Sier die Höhe des Parallax-Elementes in Pixel an.'];
$GLOBALS['TL_LANG']['tl_content']['mate_background_image'] = ['Hintergrundbild','Hier können Sie ein Hintergrundbild auswählen.'];