<?php

/*
 * This file is part of Contao.
 *
 * (c) Leo Feyer
 *
 * @license LGPL-3.0-or-later
 */

namespace Contao\CoreBundle\Controller;

use Contao\CoreBundle\Response\InitializeControllerResponse;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Event\FilterResponseEvent;
use Symfony\Component\HttpKernel\Event\FinishRequestEvent;
use Symfony\Component\HttpKernel\Event\GetResponseForExceptionEvent;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
use Symfony\Component\HttpKernel\HttpKernel;
use Symfony\Component\HttpKernel\HttpKernelInterface;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Custom controller to support legacy entry point scripts.
 *
 * @author Andreas Schempp <https://github.com/aschempp>
 *
 * @deprecated Deprecated in Contao 4.0, to be removed in Contao 5.0
 */
class InitializeController extends Controller
{
    /**
     * Initializes the Contao framework.
     *
     * @return InitializeControllerResponse
     *
     * @Route("/_contao/initialize", name="contao_initialize")
     */
    public function indexAction()
    {
        @trigger_error('Custom entry points are deprecated and will no longer work in Contao 5.0.', E_USER_DEPRECATED);

        $masterRequest = $this->get('request_stack')->getMasterRequest();
        $realRequest = Request::createFromGlobals();

        // Necessary to generate the correct base path
        foreach (['REQUEST_URI', 'SCRIPT_NAME', 'SCRIPT_FILENAME', 'PHP_SELF'] as $name) {
            $realRequest->server->set(
                $name,
                str_replace(TL_SCRIPT, 'app.php', $realRequest->server->get($name))
            );
        }

        $realRequest->attributes->replace($masterRequest->attributes->all());

        // Empty the request stack to make our real request the master
        do {
            $pop = $this->get('request_stack')->pop();
        } while ($pop);

        // Initialize the framework with the real request
        $this->get('request_stack')->push($realRequest);
        $this->get('contao.framework')->initialize();

        // Add the master request again. When Kernel::handle() is finished,
        // it will pop the current request, resulting in the real request being active.
        $this->get('request_stack')->push($masterRequest);

        set_exception_handler(function ($e) use ($realRequest) {
            // Do not catch PHP7 Throwables
            if (!$e instanceof \Exception) {
                throw $e;
            }

            $this->handleException($e, $realRequest, HttpKernelInterface::MASTER_REQUEST);
        });

        return new InitializeControllerResponse('', 204);
    }

    /**
     * Handles an exception by trying to convert it to a Response object.
     *
     * @param int $type HttpKernelInterface::MASTER_REQUEST or HttpKernelInterface::SUB_REQUEST
     *
     * @see HttpKernel::handleException()
     */
    private function handleException(\Exception $e, Request $request, $type)
    {
        $event = new GetResponseForExceptionEvent($this->get('http_kernel'), $request, $type, $e);
        $this->get('event_dispatcher')->dispatch(KernelEvents::EXCEPTION, $event);

        // A listener might have replaced the exception
        $e = $event->getException();

        if (!$event->hasResponse()) {
            throw $e;
        }

        $response = $event->getResponse();

        // The developer asked for a specific status code
        if (
            !$event->isAllowingCustomResponseCode()
            && !$response->isClientError()
            && !$response->isServerError()
            && !$response->isRedirect()
        ) {
            // Ensure that we actually have an error response
            if ($e instanceof HttpExceptionInterface) {
                // Keep the HTTP status code and headers
                $response->setStatusCode($e->getStatusCode());
                $response->headers->add($e->getHeaders());
            } else {
                $response->setStatusCode(500);
            }
        }

        try {
            $event = new FilterResponseEvent($this->get('http_kernel'), $request, $type, $response);
            $this->get('event_dispatcher')->dispatch(KernelEvents::RESPONSE, $event);
            $response = $event->getResponse();

            $this->get('event_dispatcher')->dispatch(
                KernelEvents::FINISH_REQUEST,
                new FinishRequestEvent($this->get('http_kernel'), $request, $type)
            );

            $this->get('request_stack')->pop();
        } catch (\Exception $e) {
            // ignore and continue with original response
        }

        $response->send();
        $this->get('kernel')->terminate($request, $response);
        exit;
    }
}
