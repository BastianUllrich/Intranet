# RockSolid Slider Contao Extension

## Installation

```sh
$ composer require madeyourday/contao-rocksolid-slider
```

## Documentation:

* English: https://rocksolidthemes.com/en/contao/plugins/responsive-slider
* German: https://rocksolidthemes.com/de/contao/plugins/responsive-slider

## License

* English: https://rocksolidthemes.com/en/contao/license
* German: https://rocksolidthemes.com/de/contao/lizenzbedigungen
