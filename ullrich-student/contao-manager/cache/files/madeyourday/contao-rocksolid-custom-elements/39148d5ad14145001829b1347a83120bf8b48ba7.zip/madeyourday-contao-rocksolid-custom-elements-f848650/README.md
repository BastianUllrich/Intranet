# RockSolid Custom Elements Contao Extension

## Installation

```sh
$ composer require madeyourday/contao-rocksolid-custom-elements
```

## Documentation:

* English: https://rocksolidthemes.com/en/contao/plugins/custom-content-elements
* German: https://rocksolidthemes.com/de/contao/plugins/custom-content-elements
